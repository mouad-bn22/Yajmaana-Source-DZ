import stripe
from django.conf import settings
from rest_framework import generics, status
from rest_framework.response import Response
from .models import Payment
from .serializers import PaymentSerializer

stripe.api_key = settings.STRIPE_SECRET_KEY

class PaymentView(generics.CreateAPIView):
    queryset = Payment.objects.all()
    serializer_class = PaymentSerializer

    def create(self, request, *args, **kwargs):
        user = request.user
        amount = request.data.get('amount')
        try:
            charge = stripe.Charge.create(
                amount=int(amount * 100),
                currency='usd',
                description='Payment for services',
                source=request.data.get('token')
            )
            payment = Payment.objects.create(user=user, stripe_charge_id=charge.id, amount=amount)
            return Response({'status': 'success', 'charge_id': charge.id}, status=status.HTTP_201_CREATED)
        except stripe.error.StripeError as e:
            return Response({'status': 'error', 'message': str(e)}, status=status.HTTP_400_BAD_REQUEST)