from rest_framework import serializers
from .models import BuyerProfile, SellerProfile, Match, Contract

class BuyerProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = BuyerProfile
        fields = ['id', 'user', 'preferences', 'created_at']

class SellerProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = SellerProfile
        fields = ['id', 'user', 'offerings', 'created_at']

class MatchSerializer(serializers.ModelSerializer):
    class Meta:
        model = Match
        fields = ['id', 'buyer', 'seller', 'match_score', 'created_at']

class ContractSerializer(serializers.ModelSerializer):
    class Meta:
        model = Contract
        fields = ['id', 'match', 'terms', 'buyer_signature', 'seller_signature', 'created_at']