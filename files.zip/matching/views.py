from rest_framework import generics
from .models import BuyerProfile, SellerProfile, Match, Contract
from .serializers import BuyerProfileSerializer, SellerProfileSerializer, MatchSerializer, ContractSerializer
from .ai import get_match_score, get_contract_terms

class BuyerProfileList(generics.ListCreateAPIView):
    queryset = BuyerProfile.objects.all()
    serializer_class = BuyerProfileSerializer

class SellerProfileList(generics.ListCreateAPIView):
    queryset = SellerProfile.objects.all()
    serializer_class = SellerProfileSerializer

class MatchList(generics.ListCreateAPIView):
    queryset = Match.objects.all()
    serializer_class = MatchSerializer

    def perform_create(self, serializer):
        buyer = BuyerProfile.objects.get(id=self.request.data.get('buyer'))
        seller = SellerProfile.objects.get(id=self.request.data.get('seller'))
        match_score = get_match_score(buyer, seller)
        serializer.save(buyer=buyer, seller=seller, match_score=match_score)

class ContractList(generics.ListCreateAPIView):
    queryset = Contract.objects.all()
    serializer_class = ContractSerializer

    def perform_create(self, serializer):
        match = Match.objects.get(id=self.request.data.get('match'))
        terms = get_contract_terms(match)
        serializer.save(match=match, terms=terms)