from django.db import models
from django.conf import settings

class BuyerProfile(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    preferences = models.JSONField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.user.username

class SellerProfile(models.Model):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    offerings = models.JSONField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.user.username

class Match(models.Model):
    buyer = models.ForeignKey(BuyerProfile, related_name='matches', on_delete=models.CASCADE)
    seller = models.ForeignKey(SellerProfile, related_name='matches', on_delete=models.CASCADE)
    match_score = models.FloatField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Match: {self.buyer.user.username} - {self.seller.user.username}"

class Contract(models.Model):
    match = models.OneToOneField(Match, on_delete=models.CASCADE)
    terms = models.TextField()
    buyer_signature = models.BooleanField(default=False)
    seller_signature = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Contract for Match: {self.match.id}"