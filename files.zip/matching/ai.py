import openai
from django.conf import settings

openai.api_key = settings.OPENAI_API_KEY

def get_match_score(buyer, seller):
    response = openai.Completion.create(
        engine="text-davinci-003",
        prompt=f"Calculate match score for buyer: {buyer.user.username} and seller: {seller.user.username}",
        max_tokens=50
    )
    return float(response.choices[0].text.strip())

def get_contract_terms(match):
    response = openai.Completion.create(
        engine="text-davinci-003",
        prompt=f"Generate contract terms for match between buyer: {match.buyer.user.username} and seller: {match.seller.user.username}",
        max_tokens=150
    )
    return response.choices[0].text.strip()