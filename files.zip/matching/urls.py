from django.urls import path
from .views import BuyerProfileList, SellerProfileList, MatchList, ContractList

urlpatterns = [
    path('buyers/', BuyerProfileList.as_view(), name='buyer-profile-list'),
    path('sellers/', SellerProfileList.as_view(), name='seller-profile-list'),
    path('matches/', MatchList.as_view(), name='match-list'),
    path('contracts/', ContractList.as_view(), name='contract-list'),
]