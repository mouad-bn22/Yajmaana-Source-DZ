from django.urls import path
from .views import CategoryList, TopicList, PostList, RecommendationView

urlpatterns = [
    path('categories/', CategoryList.as_view(), name='category-list'),
    path('topics/', TopicList.as_view(), name='topic-list'),
    path('posts/', PostList.as_view(), name='post-list'),
    path('recommendations/', RecommendationView.as_view(), name='recommendation-list'),
]