from django_filters import rest_framework as filters
from .models import Topic, Post

class TopicFilter(filters.FilterSet):
    class Meta:
        model = Topic
        fields = {
            'category': ['exact'],
            'created_by': ['exact'],
            'created_at': ['gte', 'lte'],
        }

class PostFilter(filters.FilterSet):
    class Meta:
        model = Post
        fields = {
            'topic': ['exact'],
            'created_by': ['exact'],
            'created_at': ['gte', 'lte'],
        }