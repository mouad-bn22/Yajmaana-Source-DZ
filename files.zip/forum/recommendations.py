import openai
from django.conf import settings

openai.api_key = settings.OPENAI_API_KEY

def get_recommendations(user_profile):
    response = openai.Completion.create(
        engine="text-davinci-003",
        prompt=f"Recommend topics and posts for user profile: {user_profile}",
        max_tokens=100
    )
    return response.choices[0].text.strip()