class Order(models.Model):
    product = models.ForeignKey(Product, related_name='orders', on_delete=models.CASCADE)
    buyer = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField()
    total_price = models.DecimalField(max_digits=10, decimal_places=2)
    created_at = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=50, default='Pending')

    def save(self, *args, **kwargs):
        self.total_price = self.product.price * self.quantity
        super().save(*args, **kwargs)
        # Automatically create an invoice for the order
        Invoice.objects.create(order=self, invoice_number=f"INV-{self.id}", due_date=self.created_at + timedelta(days=30), amount=self.total_price)

class Invoice(models.Model):
    order = models.ForeignKey(Order, related_name='invoices', on_delete=models.CASCADE)
    invoice_number = models.CharField(max_length=50)
    issued_at = models.DateTimeField(auto_now_add=True)
    due_date = models.DateTimeField()
    amount = models.DecimalField(max_digits=10, decimal_places=2)