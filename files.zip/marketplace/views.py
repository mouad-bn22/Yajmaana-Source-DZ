from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from .recommendations import get_product_recommendations

class ProductRecommendationView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, format=None):
        user_profile = request.user.username
        recommendations = get_product_recommendations(user_profile)
        return Response({"recommendations": recommendations})