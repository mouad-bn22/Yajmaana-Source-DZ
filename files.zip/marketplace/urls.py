from django.urls import path
from .views import ProductList, OrderList, InvoiceList, ProductRecommendationView

urlpatterns = [
    path('products/', ProductList.as_view(), name='product-list'),
    path('orders/', OrderList.as_view(), name='order-list'),
    path('invoices/', InvoiceList.as_view(), name='invoice-list'),
    path('recommendations/', ProductRecommendationView.as_view(), name='product-recommendation-list'),
]