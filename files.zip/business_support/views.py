from rest_framework import generics
from .models import ChatbotConversation, SearchQuery, ContentSuggestion
from .serializers import ChatbotConversationSerializer, SearchQuerySerializer, ContentSuggestionSerializer
from .ai import get_chatbot_response, get_search_results, get_content_suggestions

class ChatbotConversationList(generics.ListCreateAPIView):
    queryset = ChatbotConversation.objects.all()
    serializer_class = ChatbotConversationSerializer

    def perform_create(self, serializer):
        user = self.request.user
        message = self.request.data.get('message')
        response = get_chatbot_response(message)
        serializer.save(user=user, response=response)

class SearchQueryList(generics.ListCreateAPIView):
    queryset = SearchQuery.objects.all()
    serializer_class = SearchQuerySerializer

    def perform_create(self, serializer):
        user = self.request.user
        query = self.request.data.get('query')
        results = get_search_results(query)
        serializer.save(user=user, results=results)

class ContentSuggestionList(generics.ListCreateAPIView):
    queryset = ContentSuggestion.objects.all()
    serializer_class = ContentSuggestionSerializer

    def perform_create(self, serializer):
        user = self.request.user
        suggestion = get_content_suggestions(user)
        serializer.save(user=user, suggestion=suggestion)