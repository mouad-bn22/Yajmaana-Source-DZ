from rest_framework import serializers
from .models import ChatbotConversation, SearchQuery, ContentSuggestion

class ChatbotConversationSerializer(serializers.ModelSerializer):
    class Meta:
        model = ChatbotConversation
        fields = ['id', 'user', 'message', 'response', 'timestamp']

class SearchQuerySerializer(serializers.ModelSerializer):
    class Meta:
        model = SearchQuery
        fields = ['id', 'user', 'query', 'results', 'timestamp']

class ContentSuggestionSerializer(serializers.ModelSerializer):
    class Meta:
        model = ContentSuggestion
        fields = ['id', 'user', 'suggestion', 'timestamp']