from django.urls import path
from .views import ChatbotConversationList, SearchQueryList, ContentSuggestionList

urlpatterns = [
    path('chatbot/', ChatbotConversationList.as_view(), name='chatbot-conversation-list'),
    path('search/', SearchQueryList.as_view(), name='search-query-list'),
    path('suggestions/', ContentSuggestionList.as_view(), name='content-suggestion-list'),
]