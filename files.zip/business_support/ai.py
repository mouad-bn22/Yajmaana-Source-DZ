import openai
from django.conf import settings

openai.api_key = settings.OPENAI_API_KEY

def get_chatbot_response(message):
    response = openai.Completion.create(
        engine="text-davinci-003",
        prompt=f"User: {message}\nAI:",
        max_tokens=150
    )
    return response.choices[0].text.strip()

def get_search_results(query):
    response = openai.Completion.create(
        engine="text-davinci-003",
        prompt=f"Search for: {query}",
        max_tokens=150
    )
    return response.choices[0].text.strip()

def get_content_suggestions(user):
    response = openai.Completion.create(
        engine="text-davinci-003",
        prompt=f"Suggest content for user: {user.username}",
        max_tokens=150
    )
    return response.choices[0].text.strip()