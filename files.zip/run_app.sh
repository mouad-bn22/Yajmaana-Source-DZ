#!/bin/bash

# الخطوة 1: تثبيت التبعيات
echo "تثبيت التبعيات..."
pip install -r requirements.txt

# الخطوة 2: إعداد متغيرات البيئة
echo "إعداد متغيرات البيئة..."
export DEBUG=True
export DATABASE_URL=postgres://user:password@localhost:5432/mydatabase
export SECRET_KEY=your_secret_key

# الخطوة 3: تشغيل الترحيلات
echo "تشغيل الترحيلات..."
python manage.py migrate

# الخطوة 4: بدء التطبيق
echo "بدء التطبيق..."
python manage.py runserver

echo "التطبيق يعمل. راقب الطرفية لأي أخطاء."