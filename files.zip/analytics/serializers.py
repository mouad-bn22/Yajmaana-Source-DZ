from rest_framework import serializers
from .models import PredictiveAnalyticsData

class PredictiveAnalyticsDataSerializer(serializers.ModelSerializer):
    class Meta:
        model = PredictiveAnalyticsData
        fields = ['id', 'user', 'metric', 'predicted_value', 'actual_value', 'timestamp']