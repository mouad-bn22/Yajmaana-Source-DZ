import openai
from django.conf import settings

openai.api_key = settings.OPENAI_API_KEY

def generate_predictive_analytics(user, metric):
    response = openai.Completion.create(
        engine="text-davinci-003",
        prompt=f"Generate predictive analytics for user: {user.username} for metric: {metric}",
        max_tokens=100
    )
    return float(response.choices[0].text.strip())