from rest_framework import generics
from .models import PredictiveAnalyticsData
from .serializers import PredictiveAnalyticsDataSerializer
from .ai import generate_predictive_analytics

class PredictiveAnalyticsDataList(generics.ListCreateAPIView):
    queryset = PredictiveAnalyticsData.objects.all()
    serializer_class = PredictiveAnalyticsDataSerializer

    def perform_create(self, serializer):
        user = self.request.user
        metric = self.request.data.get('metric')
        predicted_value = generate_predictive_analytics(user, metric)
        serializer.save(user=user, metric=metric, predicted_value=predicted_value)