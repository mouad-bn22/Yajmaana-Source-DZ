from django.urls import path
from .views import PredictiveAnalyticsDataList

urlpatterns = [
    path('predictive-data/', PredictiveAnalyticsDataList.as_view(), name='predictive-analytics-data-list'),
]