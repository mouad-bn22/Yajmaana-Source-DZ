from django.urls import path
from .views import LiveSessionList, ParticipantList, TranscriptionView, EngagementList

urlpatterns = [
    path('sessions/', LiveSessionList.as_view(), name='session-list'),
    path('participants/', ParticipantList.as_view(), name='participant-list'),
    path('transcription/', TranscriptionView.as_view(), name='transcription'),
    path('engagements/', EngagementList.as_view(), name='engagement-list'),
]