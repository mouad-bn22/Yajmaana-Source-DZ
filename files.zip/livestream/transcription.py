import openai
from django.conf import settings

openai.api_key = settings.OPENAI_API_KEY

def transcribe_audio(audio_path):
    response = openai.Audio.transcribe(
        model="whisper-1",
        file=open(audio_path, "rb")
    )
    return response['text']

def summarize_text(text):
    response = openai.Completion.create(
        engine="text-davinci-003",
        prompt=f"Summarize the following text: {text}",
        max_tokens=100
    )
    return response.choices[0].text.strip()