class EngagementSerializer(serializers.ModelSerializer):
    class Meta:
        model = Engagement
        fields = ['id', 'session', 'user', 'action', 'timestamp']