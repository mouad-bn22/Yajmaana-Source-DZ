import openai
from django.conf import settings

openai.api_key = settings.OPENAI_API_KEY

def get_pricing_model(plan):
    response = openai.Completion.create(
        engine="text-davinci-003",
        prompt=f"Generate optimized pricing for plan: {plan}",
        max_tokens=50
    )
    return float(response.choices[0].text.strip())

def check_referral_reward(referrer, referred_user):
    response = openai.Completion.create(
        engine="text-davinci-003",
        prompt=f"Check if referral reward is earned for referrer: {referrer.username} and referred user: {referred_user.username}",
        max_tokens=50
    )
    reward_earned = response.choices[0].text.strip().lower() == 'true'
    if reward_earned:
        referral = Referral.objects.get(referrer=referrer, referred_user=referred_user)
        referral.reward_earned = True
        referral.save()