from django.db import models
from django.conf import settings

class Subscription(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    plan = models.CharField(max_length=50)
    start_date = models.DateTimeField(auto_now_add=True)
    end_date = models.DateTimeField()
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.user.username} - {self.plan}"

class Referral(models.Model):
    referrer = models.ForeignKey(settings.AUTH_USER_MODEL, related_name='referrals', on_delete=models.CASCADE)
    referred_user = models.ForeignKey(settings.AUTH_USER_MODEL, related_name='referred_by', on_delete=models.CASCADE)
    timestamp = models.DateTimeField(auto_now_add=True)
    reward_earned = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.referrer.username} referred {self.referred_user.username}"

class Pricing(models.Model):
    plan = models.CharField(max_length=50)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    features = models.JSONField()

    def __str__(self):
        return self.plan