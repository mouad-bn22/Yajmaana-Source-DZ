from rest_framework import generics
from .models import Subscription, Referral, Pricing
from .serializers import SubscriptionSerializer, ReferralSerializer, PricingSerializer
from .ai import get_pricing_model, check_referral_reward

class SubscriptionList(generics.ListCreateAPIView):
    queryset = Subscription.objects.all()
    serializer_class = SubscriptionSerializer

class ReferralList(generics.ListCreateAPIView):
    queryset = Referral.objects.all()
    serializer_class = ReferralSerializer

    def perform_create(self, serializer):
        referrer = self.request.user
        referred_user = self.request.data.get('referred_user')
        serializer.save(referrer=referrer, referred_user=referred_user)
        check_referral_reward(referrer, referred_user)

class PricingList(generics.ListCreateAPIView):
    queryset = Pricing.objects.all()
    serializer_class = PricingSerializer

    def perform_create(self, serializer):
        plan = self.request.data.get('plan')
        price = get_pricing_model(plan)
        serializer.save(plan=plan, price=price)