from django.urls import path
from .views import SubscriptionList, ReferralList, PricingList

urlpatterns = [
    path('subscriptions/', SubscriptionList.as_view(), name='subscription-list'),
    path('referrals/', ReferralList.as_view(), name='referral-list'),
    path('pricing/', PricingList.as_view(), name='pricing-list'),
]